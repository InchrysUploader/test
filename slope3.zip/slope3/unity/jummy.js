UnityCallPlayJs = function () {
  console.log("--UnityCallPlayJs--");
}

UnityCallAgainJs = function () {
  console.log("--UnityCallAgainJs--");
}

UnityCallBackHomeJs = function () {
  console.log("--UnityCallBackHomeJs--");
}

UnityCallLeaderboardJs = function () {
  console.log("--UnityCallLeaderboardJs--");
}
UnityCallEndgameJs = function () {
  console.log("--UnityCallEndgameJs--");
}

UnityCallPassLevel = function () {
  console.log("--UnityCallPassLevel--");
}

UnityCallMiniMapJs = function () {
  console.log("--UnityCallMiniMapJs--");
}

UnityCallChangeDayLeaderboardJs = function () {
  console.log("--UnityCallChangeDayLeaderboardJs--");
}

UnityCallCloseLeaderboardJs = function () {
  console.log("--UnityCallCloseLeaderboardJs--");
}
